#!/usr/bin/env python3
"""Guard one existing-PR text or ready mutation with exact state checks."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Any, Iterator

WRITER_SCRIPTS = (
    Path(__file__).parents[2] / "writing-reviewable-pr-descriptions/scripts"
)
if str(WRITER_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(WRITER_SCRIPTS))
from change_navigation.review_input import (  # noqa: E402
    PR_NUMBER_TOKEN,
    ReviewInputError,
    bind_review_input,
    load_review_input,
)
from change_navigation.bot_body import (  # noqa: E402
    BotBodyError,
    authored_body,
    merge_bot_tail,
)
from change_navigation.sensitive_content import suspected_secret_error  # noqa: E402
from publication_receipts import (  # noqa: E402
    LedgerLease,
    load_receipts,
    prepare_receipt_ledger,
    prepare_receipt_store,
    receipt_ledger_lock,
    receipt_matches_live,
    record_verified_publication,
    resolve_receipt_root,
    verified_transition,
)
from publication_receipts import SCHEMA_VERSION as RECEIPT_SCHEMA_VERSION  # noqa: E402
from publication_support import (  # noqa: E402
    expected_identity as _expected_identity,
)
from publication_support import (  # noqa: E402
    temporary_body as _write_temporary_body,
)
from publication_support import (  # noqa: E402
    validate_pr_content as _validate_body,
)
from required_review import (  # noqa: E402
    PublicationCandidate,
    validate_review_input_binding,
)
from required_review import (  # noqa: E402
    build_candidate as _build_candidate,
)
from required_review import (  # noqa: E402
    validate_required_review as _validate_required_review,
)
from reviewable_pr_state import (  # noqa: E402
    ExpectedIdentity,
    MutationAmbiguousError,
    PublicationError,
    github_repository,
    identity_matches,
)
from reviewable_pr_state import (  # noqa: E402
    run_mutation as _run_mutation,
)
from reviewable_pr_state import (  # noqa: E402
    stored_pr as _stored_pr,
)

SHA256_RE = re.compile(r"[0-9a-f]{64}")
MAX_PR_BODY_CHARACTERS = 65536


def _digest(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _validate_published_body_size(body: str) -> None:
    if len(body) > MAX_PR_BODY_CHARACTERS:
        raise PublicationError(
            "published PR body exceeds GitHub's 65536-character limit after "
            "retaining the live bot suffix"
        )


def _sealed_body(body: str, expected_sha256: str) -> str:
    try:
        return authored_body(body, expected_sha256=expected_sha256)
    except BotBodyError as error:
        raise PublicationError(
            "PR title/body/draft preimage changed before mutation"
        ) from error


def _state_matches_owned_body(
    stored: dict[str, Any],
    expected: ExpectedIdentity,
    *,
    title: str,
    body: str,
    is_draft: bool,
) -> bool:
    try:
        observed_body = _sealed_body(str(stored.get("body", "")), _digest(body))
    except PublicationError:
        return False
    return (
        identity_matches(stored, expected)
        and stored.get("title") == title
        and isinstance(stored.get("body"), str)
        and observed_body == body
        and stored.get("isDraft") is is_draft
        and stored.get("state") == "OPEN"
    )


def _read_body(path: Path) -> tuple[str, bytes]:
    if not path.is_absolute():
        raise PublicationError("body file path must be absolute")
    try:
        raw = path.read_bytes()
        body = raw.decode("utf-8")
    except (OSError, UnicodeDecodeError) as error:
        raise PublicationError(f"cannot read body file: {error}") from error
    if suspected_secret_error(body) is not None:
        raise PublicationError(
            "PR body contains a suspected credential or secret; publication is blocked"
        )
    return body, raw


def _read_body_source(
    *, body_path: Path | None, template_path: Path | None, pr_number: int
) -> tuple[str, str | None, bytes, str]:
    if (body_path is None) == (template_path is None):
        raise PublicationError(
            "provide exactly one of body file or new-PR body template"
        )
    if body_path is not None:
        body, raw = _read_body(body_path)
        return body, None, raw, "body"
    assert template_path is not None
    template, raw = _read_body(template_path)
    if PR_NUMBER_TOKEN not in template:
        raise PublicationError(f"body template must contain {PR_NUMBER_TOKEN}")
    return template.replace(PR_NUMBER_TOKEN, str(pr_number)), template, raw, "template"


def _reject_secret_text(*values: str) -> None:
    if any(suspected_secret_error(value) is not None for value in values):
        raise PublicationError(
            "PR publication text contains a suspected credential or secret; "
            "publication is blocked pending authorized removal and rotation"
        )


def _preflight(
    *,
    expected: ExpectedIdentity,
    expected_title_sha256: str,
    expected_body_sha256: str,
    expected_draft: bool | None,
) -> dict[str, Any]:
    if SHA256_RE.fullmatch(expected_title_sha256) is None:
        raise PublicationError("expected title SHA-256 must be 64 lowercase hex digits")
    if SHA256_RE.fullmatch(expected_body_sha256) is None:
        raise PublicationError("expected body SHA-256 must be 64 lowercase hex digits")
    stored = _stored_pr(expected.repository, expected.pr_number)
    if not identity_matches(stored, expected):
        raise PublicationError(
            "PR identity or pushed base/head changed before mutation"
        )
    title = stored.get("title")
    body = stored.get("body")
    if not isinstance(title, str) or not isinstance(body, str):
        raise PublicationError("PR title/body preimage is unreadable")
    _reject_secret_text(title, body)
    _sealed_body(body, expected_body_sha256)
    if (
        _digest(title) != expected_title_sha256
        or (
            expected_draft is not None
            and stored.get("isDraft") is not expected_draft
        )
    ):
        raise PublicationError("PR title/body/draft preimage changed before mutation")
    return stored


def _bind_review_input(
    review_input_path: Path,
    expected: ExpectedIdentity,
    title: str,
    body: str,
    stored_title: str | None = None,
    stored_body: str | None = None,
    template_body: str | None = None,
) -> tuple[int, str]:
    try:
        manifest = load_review_input(review_input_path)
        bind_review_input(
            manifest,
            repository=expected.repository,
            pr_number=expected.pr_number,
            base=expected.base,
            base_oid=expected.base_oid,
            head=expected.head,
            head_oid=expected.head_oid,
            head_owner=expected.head_owner,
            head_repository=expected.head_repository,
            title=title,
            body=body,
            stored_title=stored_title,
            stored_body=stored_body,
            template_body=template_body,
            git_repository=Path.cwd(),
        )
        return int(manifest.raw["version"]), manifest.content_sha256
    except ReviewInputError as error:
        raise PublicationError(f"review input drift: {error}") from error


def _token_review_input(review_input_path: Path) -> Any | None:
    """Return a token-bearing manifest, leaving malformed input to the binder."""

    try:
        manifest = load_review_input(review_input_path)
    except ReviewInputError:
        return None
    if manifest.raw["pr_number"] != PR_NUMBER_TOKEN:
        return None
    return manifest


def _resolve_ready_template(
    *,
    review_input_path: Path,
    expected: ExpectedIdentity,
    body: str,
    body_template_path: Path | None,
) -> str | None:
    """Resolve the source bytes needed to rebind a new-PR manifest."""

    manifest = _token_review_input(review_input_path)
    if manifest is None:
        return None
    if body_template_path is not None:
        template, _ = _read_body(body_template_path)
    else:
        rendered_number = str(expected.pr_number)
        template = body.replace(rendered_number, PR_NUMBER_TOKEN)
        if template == body or PR_NUMBER_TOKEN not in template:
            raise PublicationError(
                "token-based review input needs the original body template; "
                "pass --body-template to prove its rendering"
            )
    candidate = manifest.raw.get("candidate")
    if (
        not isinstance(candidate, dict)
        or candidate.get("body_sha256") != _digest(template)
    ):
        raise PublicationError(
            "token-based review input does not match the supplied or derived "
            "body template"
        )
    if template.replace(PR_NUMBER_TOKEN, str(expected.pr_number)) != body:
        raise PublicationError(
            "token-based review input renders a different live PR body"
        )
    return template


@contextmanager
def _ready_template_file(
    template: str | None, body_template_path: Path | None
) -> Iterator[Path | None]:
    """Expose a verified token template to the navigation validator."""

    if template is None:
        yield None
        return
    if body_template_path is not None:
        yield body_template_path
        return
    with _write_temporary_body(template) as body_file:
        yield Path(body_file.name)


def _build_ready_candidate(
    *,
    expected: ExpectedIdentity,
    title: str,
    body: str,
    review_input_path: Path,
    review_mode: str,
    selected_specialists: list[str],
) -> PublicationCandidate:
    candidate = _build_candidate(
        operation="mark-ready",
        repository=expected.repository,
        pr_number=expected.pr_number,
        base=expected.base,
        base_oid=expected.base_oid,
        head=expected.head,
        head_oid=expected.head_oid,
        head_owner=expected.head_owner,
        head_repository=expected.head_repository,
        title=title,
        body_source_kind="stored-body",
        body_source_raw=body.encode("utf-8"),
        published_body=body,
        review_input_path=review_input_path,
        review_mode=review_mode,
        selected_specialists=selected_specialists,
    )
    return candidate


def _require_creation_receipt(
    *,
    expected: ExpectedIdentity,
    before: dict[str, Any],
    template: str,
    review_input_path: Path,
    review_input_schema_version: int,
    review_input_sha256: str,
    review_mode: str,
    selected_specialists: list[str],
    receipt_root: Path,
    verified_ready_body: str | None = None,
) -> None:
    """Bind creation bytes, using a verified v4 ready body for historical proof."""

    receipts = load_receipts(receipt_root, expected)
    if not receipts or receipts[0].operation != "create":
        raise PublicationError(
            "token-based readiness requires the canonical creation receipt for "
            "this PR"
        )
    creation = receipts[0]
    creation_body = (
        str(before["body"])
        if verified_ready_body is None
        else verified_ready_body
    )
    if creation.schema_version >= RECEIPT_SCHEMA_VERSION:
        creation_body = _sealed_body(creation_body, creation.final_state.body_sha256)
    if (
        creation.provenance != "canonical"
        or creation.review is None
        or creation.expected != expected
        or creation.review_input_schema_version != review_input_schema_version
        or creation.review_input_sha256 != review_input_sha256
        or creation.final_state.title_sha256 != _digest(str(before["title"]))
        or creation.final_state.body_sha256 != _digest(creation_body)
        or creation.final_state.is_draft is not True
    ):
        raise PublicationError(
            "canonical creation receipt does not match the current PR or "
            "token-based review input"
        )
    candidate = _build_candidate(
        operation="create",
        repository=expected.repository,
        pr_number=PR_NUMBER_TOKEN,
        base=expected.base,
        base_oid=expected.base_oid,
        head=expected.head,
        head_oid=expected.head_oid,
        head_owner=expected.head_owner,
        head_repository=expected.head_repository,
        title=str(before["title"]),
        body_source_kind="template",
        body_source_raw=template.encode("utf-8"),
        published_body=template,
        review_input_path=review_input_path,
        review_mode=review_mode,
        selected_specialists=selected_specialists,
    )
    validate_review_input_binding(
        candidate,
        review_input_schema_version,
        review_input_sha256,
        review_input_path,
    )
    if (
        creation.review.mode != review_mode
        or creation.review.publication_candidate_sha256 != candidate.content_sha256
    ):
        raise PublicationError(
            "canonical creation receipt review mode or selected specialists drifted"
        )
    if before.get("isDraft") is True and any(
        receipt.operation == "mark-ready" and receipt.provenance == "canonical"
        for receipt in receipts
    ):
        raise PublicationError(
            "this PR already has a canonical ready transition; token-based "
            "readiness cannot publish it again after redraft; use fresh numbered "
            "review input"
        )


def _return_idempotent_ready(
    *,
    expected: ExpectedIdentity,
    before: dict[str, Any],
    expected_body_sha256: str,
    review_input_path: Path,
    template: str | None,
    review_mode: str,
    selected_specialists: list[str],
    receipt_root: Path,
) -> dict[str, Any]:
    """Return a previously verified ready state without writing again."""

    title = str(before["title"])
    body = _sealed_body(str(before["body"]), expected_body_sha256)
    review_input_schema_version, review_input_sha256 = _bind_review_input(
        review_input_path,
        expected,
        title,
        body,
        title,
        body,
        template,
    )
    candidate = _build_ready_candidate(
        expected=expected,
        title=title,
        body=body,
        review_input_path=review_input_path,
        review_mode=review_mode,
        selected_specialists=selected_specialists,
    )
    validate_review_input_binding(
        candidate,
        review_input_schema_version,
        review_input_sha256,
        review_input_path,
    )
    receipts = load_receipts(receipt_root, expected)
    if not receipts:
        raise PublicationError(
            "PR is already ready but has no canonical readiness receipt; "
            "no mutation was attempted"
        )
    receipt = receipts[-1]
    if (
        receipt.operation != "mark-ready"
        or receipt.provenance != "canonical"
        or receipt.review is None
        or receipt.review.mode != review_mode
        or receipt.review.publication_candidate_sha256 != candidate.content_sha256
        or receipt.review_input_schema_version != review_input_schema_version
        or receipt.review_input_sha256 != review_input_sha256
        or not receipt_matches_live(receipt, before)
    ):
        raise PublicationError(
            "PR is already ready but its canonical readiness receipt does not "
            "match the supplied identity, body, or review inputs"
        )
    if template is not None:
        _require_creation_receipt(
            expected=expected,
            before=before,
            template=template,
            review_input_path=review_input_path,
            review_input_schema_version=review_input_schema_version,
            review_input_sha256=review_input_sha256,
            review_mode=review_mode,
            selected_specialists=selected_specialists,
            receipt_root=receipt_root,
            verified_ready_body=(
                body if receipt.schema_version >= RECEIPT_SCHEMA_VERSION else None
            ),
        )
    return before


def _update_text_locked(
    *,
    expected: ExpectedIdentity,
    expected_title_sha256: str,
    expected_body_sha256: str,
    expected_draft: bool,
    title: str,
    body: str,
    template_body: str | None,
    review_input_path: Path,
    text_scope: str,
    receipt_root: Path,
    lease: LedgerLease,
    body_source_raw: bytes,
    body_source_kind: str,
    review_mode: str,
    review_bundle_root: Path | None,
    selected_specialists: list[str],
) -> dict[str, Any]:
    before = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=expected_draft,
    )
    if text_scope not in {"body-only", "title-only", "title-body"}:
        raise PublicationError(
            "text scope must be body-only, title-only, or title-body"
        )
    if text_scope == "body-only" and title != before["title"]:
        raise PublicationError("body-only edit changed the live title")
    if text_scope == "title-only" and body != _sealed_body(
        str(before["body"]), expected_body_sha256
    ):
        raise PublicationError("title-only edit changed the live body")
    published_body = merge_bot_tail(
        body, str(before["body"]), expected_live_sha256=expected_body_sha256
    )
    _validate_published_body_size(published_body)
    if title == before["title"] and body == _sealed_body(
        str(before["body"]), expected_body_sha256
    ):
        raise PublicationError("text publication is a no-op; no mutation was attempted")
    candidate = _build_candidate(
        operation="update-text",
        repository=expected.repository,
        pr_number=expected.pr_number,
        base=expected.base,
        base_oid=expected.base_oid,
        head=expected.head,
        head_oid=expected.head_oid,
        head_owner=expected.head_owner,
        head_repository=expected.head_repository,
        title=title,
        body_source_kind=body_source_kind,
        body_source_raw=body_source_raw,
        published_body=body,
        review_input_path=review_input_path,
        review_mode=review_mode,
        selected_specialists=selected_specialists,
    )
    review_input_schema_version, review_input_sha256 = _bind_review_input(
        review_input_path,
        expected,
        title,
        body,
        str(before["title"]),
        _sealed_body(str(before["body"]), expected_body_sha256),
        template_body,
    )
    validate_review_input_binding(
        candidate,
        review_input_schema_version,
        review_input_sha256,
        review_input_path,
    )
    review = _validate_required_review(
        review_mode=review_mode,
        review_bundle_root=review_bundle_root,
        candidate=candidate,
    )
    final_before = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=expected_draft,
    )
    if (
        final_before["title"] != before["title"]
        or _sealed_body(str(final_before["body"]), expected_body_sha256)
        != _sealed_body(str(before["body"]), expected_body_sha256)
        or final_before["isDraft"] is not before["isDraft"]
    ):
        raise PublicationError("PR state changed during publication validation")
    before = final_before
    published_body = merge_bot_tail(
        body, str(before["body"]), expected_live_sha256=expected_body_sha256
    )
    _validate_published_body_size(published_body)
    command_error: PublicationError | None = None
    body_context = (
        nullcontext(None)
        if text_scope == "title-only"
        else _write_temporary_body(published_body)
    )
    with body_context as body_file:
        command = [
            "gh",
            "-R",
            github_repository(expected.repository),
            "pr",
            "edit",
            str(expected.pr_number),
        ]
        if text_scope in {"title-only", "title-body"}:
            command.extend(["--title", title])
        if text_scope in {"body-only", "title-body"}:
            if body_file is None:
                raise PublicationError("body-scoped edit lost its body snapshot")
            command.extend(["--body-file", body_file.name])
        try:
            _run_mutation(command)
        except PublicationError as error:
            command_error = error
    after = _stored_pr(expected.repository, expected.pr_number)
    if command_error is not None:
        if isinstance(command_error, MutationAmbiguousError):
            raise MutationAmbiguousError(
                "PR text command was ambiguous; a matching reread cannot prove "
                "causality, so canonical provenance was not minted; do not retry"
            ) from command_error
        raise PublicationError(
            "PR text command failed; a matching reread cannot prove causality, "
            "so canonical provenance was not minted"
        ) from command_error
    if _state_matches_owned_body(
        after,
        expected,
        title=title,
        body=body,
        is_draft=expected_draft,
    ):
        transition = verified_transition(
            expected=expected,
            operation="update-text",
            preimage=before,
            final_reread=after,
            review_input_schema_version=review_input_schema_version,
            review_input_sha256=review_input_sha256,
            review=review,
            candidate=candidate,
            final_body=str(after["body"]),
            preimage_body_sha256=expected_body_sha256,
            final_body_sha256=_digest(body),
        )
        record_verified_publication(
            root=receipt_root, transition=transition, lease=lease
        )
        return after
    if after == before:
        raise PublicationError("PR text mutation was not stored")
    raise PublicationError(
        "PR text mutation has an ambiguous result; no retry or rollback was attempted"
    )


def _mark_ready_locked(
    *,
    expected: ExpectedIdentity,
    expected_title_sha256: str,
    expected_body_sha256: str,
    review_input_path: Path,
    receipt_root: Path,
    lease: LedgerLease,
    review_mode: str,
    review_bundle_root: Path | None,
    selected_specialists: list[str],
    template: str | None = None,
) -> dict[str, Any]:
    before = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=None,
    )
    is_draft = before.get("isDraft")
    if type(is_draft) is not bool:
        raise PublicationError("PR draft state is unreadable")
    if is_draft is False:
        return _return_idempotent_ready(
            expected=expected,
            before=before,
            expected_body_sha256=expected_body_sha256,
            review_input_path=review_input_path,
            template=template,
            review_mode=review_mode,
            selected_specialists=selected_specialists,
            receipt_root=receipt_root,
        )
    title = str(before["title"])
    body = _sealed_body(str(before["body"]), expected_body_sha256)
    review_input_schema_version, review_input_sha256 = _bind_review_input(
        review_input_path,
        expected,
        title,
        body,
        str(before["title"]),
        _sealed_body(str(before["body"]), expected_body_sha256),
        template,
    )
    if template is not None:
        _require_creation_receipt(
            expected=expected,
            before=before,
            template=template,
            review_input_path=review_input_path,
            review_input_schema_version=review_input_schema_version,
            review_input_sha256=review_input_sha256,
            review_mode=review_mode,
            selected_specialists=selected_specialists,
            receipt_root=receipt_root,
        )
    candidate = _build_ready_candidate(
        expected=expected,
        title=title,
        body=body,
        review_input_path=review_input_path,
        review_mode=review_mode,
        selected_specialists=selected_specialists,
    )
    validate_review_input_binding(
        candidate,
        review_input_schema_version,
        review_input_sha256,
        review_input_path,
    )
    review = _validate_required_review(
        review_mode=review_mode,
        review_bundle_root=review_bundle_root,
        candidate=candidate,
    )
    final_before = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=True,
    )
    if (
        final_before["title"] != before["title"]
        or _sealed_body(str(final_before["body"]), expected_body_sha256)
        != _sealed_body(str(before["body"]), expected_body_sha256)
        or final_before["isDraft"] is not before["isDraft"]
    ):
        raise PublicationError("PR state changed during publication validation")
    before = final_before
    command_error: PublicationError | None = None
    try:
        _run_mutation(
            [
                "gh",
                "-R",
                github_repository(expected.repository),
                "pr",
                "ready",
                str(expected.pr_number),
            ]
        )
    except PublicationError as error:
        command_error = error
    after = _stored_pr(expected.repository, expected.pr_number)
    if command_error is not None:
        if isinstance(command_error, MutationAmbiguousError):
            raise MutationAmbiguousError(
                "ready command was ambiguous; a matching reread cannot prove "
                "causality, so canonical provenance was not minted; do not retry"
            ) from command_error
        raise PublicationError(
            "ready command failed; a matching reread cannot prove causality, "
            "so canonical provenance was not minted"
        ) from command_error
    if _state_matches_owned_body(
        after, expected, title=title, body=body, is_draft=False
    ):
        transition = verified_transition(
            expected=expected,
            operation="mark-ready",
            preimage=before,
            final_reread=after,
            review_input_schema_version=review_input_schema_version,
            review_input_sha256=review_input_sha256,
            review=review,
            candidate=candidate,
            final_body=str(after["body"]),
            preimage_body_sha256=expected_body_sha256,
            final_body_sha256=_digest(body),
        )
        record_verified_publication(
            root=receipt_root, transition=transition, lease=lease
        )
        return after
    if after == before:
        raise PublicationError("PR remains a verified canonical draft")
    raise PublicationError(
        "ready mutation has an ambiguous result; no retry or rollback was attempted"
    )


def update_text(
    *,
    expected: ExpectedIdentity,
    expected_title_sha256: str,
    expected_body_sha256: str,
    expected_draft: bool,
    title: str,
    body_path: Path | None = None,
    body_template_path: Path | None = None,
    review_input_path: Path,
    review_mode: str,
    review_bundle_root: Path | None,
    selected_specialists: list[str],
    text_scope: str = "title-body",
    receipt_directory: Path | None = None,
) -> dict[str, Any]:
    if not title.strip():
        raise PublicationError("title must be non-empty")
    body, template_body, body_source_raw, body_source_kind = _read_body_source(
        body_path=body_path,
        template_path=body_template_path,
        pr_number=expected.pr_number,
    )
    _reject_secret_text(title, body)
    validation_arguments = (
        body,
        expected.repository,
        expected.pr_number,
        title,
        review_input_path,
    )
    if body_template_path is None:
        _validate_body(*validation_arguments)
    else:
        _validate_body(*validation_arguments, body_template_path)
    early = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=expected_draft,
    )
    if text_scope not in {"body-only", "title-only", "title-body"}:
        raise PublicationError(
            "text scope must be body-only, title-only, or title-body"
        )
    if text_scope == "body-only" and title != early["title"]:
        raise PublicationError("body-only edit changed the live title")
    if text_scope == "title-only" and body != _sealed_body(
        str(early["body"]), expected_body_sha256
    ):
        raise PublicationError("title-only edit changed the live body")
    if title == early["title"] and body == _sealed_body(
        str(early["body"]), expected_body_sha256
    ):
        raise PublicationError("text publication is a no-op; no mutation was attempted")
    receipt_root = prepare_receipt_store(receipt_directory)
    prepare_receipt_ledger(receipt_root, expected)
    with receipt_ledger_lock(receipt_root, expected) as lease:
        return _update_text_locked(
            expected=expected,
            expected_title_sha256=expected_title_sha256,
            expected_body_sha256=expected_body_sha256,
            expected_draft=expected_draft,
            title=title,
            body=body,
            template_body=template_body,
            review_input_path=review_input_path,
            text_scope=text_scope,
            receipt_root=receipt_root,
            lease=lease,
            body_source_raw=body_source_raw,
            body_source_kind=body_source_kind,
            review_mode=review_mode,
            review_bundle_root=review_bundle_root,
            selected_specialists=selected_specialists,
        )


def mark_ready(
    *,
    expected: ExpectedIdentity,
    expected_title_sha256: str,
    expected_body_sha256: str,
    review_input_path: Path,
    review_mode: str,
    review_bundle_root: Path | None,
    selected_specialists: list[str],
    body_template_path: Path | None = None,
    receipt_directory: Path | None = None,
) -> dict[str, Any]:
    validated = _preflight(
        expected=expected,
        expected_title_sha256=expected_title_sha256,
        expected_body_sha256=expected_body_sha256,
        expected_draft=None,
    )
    is_draft = validated.get("isDraft")
    if type(is_draft) is not bool:
        raise PublicationError("PR draft state is unreadable")
    title = str(validated["title"])
    body = _sealed_body(str(validated["body"]), expected_body_sha256)
    template = _resolve_ready_template(
        review_input_path=review_input_path,
        expected=expected,
        body=body,
        body_template_path=body_template_path,
    )
    with _ready_template_file(template, body_template_path) as validator_template:
        _validate_body(
            body,
            expected.repository,
            expected.pr_number,
            title,
            review_input_path,
            validator_template,
        )
    receipt_root = prepare_receipt_store(receipt_directory)
    prepare_receipt_ledger(receipt_root, expected)
    with receipt_ledger_lock(receipt_root, expected) as lease:
        return _mark_ready_locked(
            expected=expected,
            expected_title_sha256=expected_title_sha256,
            expected_body_sha256=expected_body_sha256,
            review_input_path=review_input_path,
            receipt_root=receipt_root,
            lease=lease,
            review_mode=review_mode,
            review_bundle_root=review_bundle_root,
            selected_specialists=selected_specialists,
            template=template,
        )


def _expected(args: argparse.Namespace) -> ExpectedIdentity:
    return _expected_identity(
        repository=args.repository,
        pr_number=args.pr,
        base=args.base,
        base_oid=args.base_oid,
        head=args.head,
        head_oid=args.head_oid,
        head_owner=args.head_owner,
        head_repository=args.head_repository,
    )


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--repository", required=True)
    parser.add_argument("--pr", required=True, type=int)
    parser.add_argument("--base", required=True)
    parser.add_argument("--base-oid", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--head-oid", required=True)
    parser.add_argument("--head-owner", required=True)
    parser.add_argument("--head-repository", required=True)
    parser.add_argument("--expected-title-sha256", required=True)
    parser.add_argument("--expected-body-sha256", required=True)
    parser.add_argument("--review-input", required=True, type=Path)
    parser.add_argument(
        "--review-mode", choices=("required", "not-required"), required=True
    )
    parser.add_argument("--review-bundle", type=Path)
    parser.add_argument(
        "--selected-specialists",
        required=True,
        help="sorted unique specialist names as a JSON array; use [] for none",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="operation", required=True)
    text_parser = subparsers.add_parser("text")
    _add_common(text_parser)
    text_parser.add_argument(
        "--expected-state", choices=("draft", "ready"), required=True
    )
    text_parser.add_argument(
        "--text-scope",
        choices=("body-only", "title-only", "title-body"),
        required=True,
    )
    text_parser.add_argument("--title", required=True)
    body_source = text_parser.add_mutually_exclusive_group(required=True)
    body_source.add_argument("--body-file", type=Path)
    body_source.add_argument("--body-template", type=Path)
    ready_parser = subparsers.add_parser("ready")
    _add_common(ready_parser)
    ready_parser.add_argument(
        "--body-template",
        type=Path,
        help="original token-bearing create body template when reusing a new-PR manifest",
    )
    args = parser.parse_args()
    try:
        try:
            selected_specialists = json.loads(args.selected_specialists)
        except json.JSONDecodeError as error:
            raise PublicationError(
                "selected review specialists must be a JSON array"
            ) from error
        expected = _expected(args)
        if args.operation == "text":
            stored = update_text(
                expected=expected,
                expected_title_sha256=args.expected_title_sha256,
                expected_body_sha256=args.expected_body_sha256,
                expected_draft=args.expected_state == "draft",
                title=args.title,
                body_path=args.body_file,
                body_template_path=args.body_template,
                review_input_path=args.review_input,
                review_mode=args.review_mode,
                review_bundle_root=args.review_bundle,
                selected_specialists=selected_specialists,
                text_scope=args.text_scope,
                receipt_directory=None,
            )
        else:
            stored = mark_ready(
                expected=expected,
                expected_title_sha256=args.expected_title_sha256,
                expected_body_sha256=args.expected_body_sha256,
                review_input_path=args.review_input,
                review_mode=args.review_mode,
                review_bundle_root=args.review_bundle,
                selected_specialists=selected_specialists,
                body_template_path=args.body_template,
                receipt_directory=None,
            )
    except PublicationError as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    receipt = load_receipts(resolve_receipt_root(), expected)[-1]
    print(
        json.dumps(
            {
                "repository": expected.repository,
                "pr": expected.pr_number,
                "url": expected.url,
                "is_draft": stored["isDraft"],
                **receipt.summary("verified"),
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
