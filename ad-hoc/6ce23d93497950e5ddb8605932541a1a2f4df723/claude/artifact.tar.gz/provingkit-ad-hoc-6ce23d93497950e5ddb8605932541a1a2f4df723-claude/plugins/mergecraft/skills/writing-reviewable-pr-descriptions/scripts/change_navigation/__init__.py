"""Change-navigation validation helpers."""
