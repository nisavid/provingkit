---
name: choosing-agent-models
description: Use when creating an agent thread, task, session, or subagent after delegation, selecting model and effort for continuations, classifying security scope, or diagnosing routing blocks or refusals.
---

# Choosing Agent Models

## Scope

Own model and effort selection after [delegating-cross-agent-work](../delegating-cross-agent-work/SKILL.md) settles target, ownership, transport, authority, and assurance. Model choice is a separate decision; it cannot repair those boundaries. Classify the complete bounded operation before each dispatch, continuation, follow-up, and review; read [scope classification and refusal diagnosis](references/classifying-security-work.md). Previous assignments do not carry classification forward.

## Selection Order

Apply [effort eligibility](references/effort-policy.md) to every route: Astra/Fable and Sol/Opus require `medium` or higher, including inherited or fixed selection; OpenAI and Anthropic `max` requires every model, problem, workflow, and capability gate. Terra Low/Medium/High follow their task and role boundaries; exclude Luna XHigh/Max and Sol Light.

1. Select Jev first only when the **complete narrow operation** is a suitable System One typed text judgment and current availability, capability, effort eligibility, and authority pass; then stop selection. [Check all gates](references/jev-suitability.md).
2. For actual cybersecurity work, obviously cybersecurity-related work with another primary domain, and cybersecurity-adjacent work, apply [Daybreak Blue routing and fallbacks](references/daybreak-routing.md).
3. Otherwise use [general tiers and preferences](references/general-tiers.md): Sol/Opus serve ordinary demanding roles; Terra bridges economical tiers; Haiku/Luna/proven Grok serve bounded work; Astra/proven Fable require the exceptional-tier conjunction.

## Prove Target Capability

Every new agent thread, task, session, or subagent must deliberately select
model and effort under the selection order and pass both supported creation
fields. Global, desktop, and
parent defaults never substitute for an exposed selection field. Set the model
on a model-only surface and record the missing effort control. Inherit model
only without a model field; record the proven binding and reason. Apply the
[field and continuation rules](references/capability-probes-and-fallbacks.md#pass-every-supported-selection-field)
including native Codex subagents and Claude Code's Agent tool.

Use the newest proven version of the same named GPT or Claude model, preserving its role and gates. Earlier Sol versions are superseded by GPT-6.1 Sol. Read [capability and fallbacks](references/capability-probes-and-fallbacks.md) for successor identity, exact catalog/schema intersection, fixed selection, Fable proof, and unavailable routes. Never invent a slug, infer support from another surface, or treat selection as invocation authority. Return `adapter:model-selection-record` for ordinary same-leader selection. It proves the selected request and observed capability, not actual execution or authority.
