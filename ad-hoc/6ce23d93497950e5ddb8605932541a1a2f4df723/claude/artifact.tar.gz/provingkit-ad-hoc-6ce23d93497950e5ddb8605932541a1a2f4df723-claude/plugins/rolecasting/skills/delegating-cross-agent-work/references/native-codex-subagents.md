# Native Codex subagents

This is the operational binding for ChatGPT Codex, Codex CLI/TUI, and Codex
Desktop. They are separate target surfaces with separate adapter profiles and use
the harness's native subagent tool as a leader-owned child transport. The
strict-profile binding is skill-mediated: `native_codex.py` sequences freeze and record state,
while the skill invokes the native tool between those operations. The module is
not a launcher and does not turn caller-supplied facts into portable
attestation.

The normal topology for each profile is:

| Dimension | ChatGPT Codex | Codex CLI/TUI | Codex Desktop |
| --- | --- | --- | --- |
| Product family | `codex` | `codex` | `codex` |
| Surface | `chatgpt-codex` | `codex-cli-tui` | `codex-desktop` |
| Relationship | `child` | `child` | `child` |
| Ownership | `leader-owned` | `leader-owned` | `leader-owned` |
| Transport | `native-tool` | `native-tool` | `native-tool` |

Do not use this binding to create or steer a user-owned task. That ownership
requires explicit user consent and a separately classified route.
App-server is an optional later transport, not a Codex surface and not an
initial-release dependency.

## Select the ordinary Cloud native-tree profile

Ordinary current-tree Cloud child operations use the separate `native_tree.py`
driver through [the native-tree procedure](native-tree-driver.md). Select its explicit versioned
profile and schema, bound to the current surface and native controls; missing
legacy fields do not select this profile automatically. The strict
`native_codex.py` records and their readers remain unchanged. Desktop, CLI/TUI,
and consumers requiring the strict record use the strict procedure below.

Freeze the bounded operation, current controller, native target binding and
generation, requested selection, capability observations, authority, and
consumer minimum before dispatch. Model choice still belongs to
`choosing-agent-models`. Native children remain leader-owned; logical role names
supply neither native identity nor authority. For independent review, preserve
the read-only invocation plan, denied onward authority, closed dispatch set,
and distinct observed execution contexts. A generic coordination operation
cannot borrow that review plan as permission for additional actions.

Bind the canonical target only from the controller's returned or observed
identity. Keep separate agent, task, and session IDs only when independently
exposed. A missing separate session ID is permitted; copying the target into a
second ID is not evidence. Product build may be explicitly unavailable only
for this ordinary profile with its frozen surface/capability binding. An
environment publication version cannot replace it. A consumer requiring an
observed product version or stronger evidence still blocks; this exception
does not apply to Desktop, CLI/TUI, or witnessed evidence.

Use the driver's immutable command and transactional claim before making one
native call. Only the newly successful claimant may emit that attempt. Record
the raw observation and its source; the driver does not invoke native tools
from a shell. Preserve an uncertain attempt before reconciliation instead of
automatically resending. Native arguments contain only supported fields;
application correlation and explicit reply intent belong inside messages.

The maximum-assurance table below is a ceiling, not achieved evidence. For
this profile, derive each achieved dimension only from supplied observations.
Unknown shapes remain unknown. A running previous status does not prove a
finished interruption, and a wait timeout does not prove nondelivery. A native
parent final does not establish sibling-owner acceptance. Missing or unverified
results remain unusable; preserve strict Boolean usability and explicit owner
verification. Worker prose cannot supply native provenance or promote a weaker
dimension. These records remain ordinary same-controller evidence, not portable
attestation.

Continue only while the controller, target/generation, requested selection,
authority, and required capabilities remain current, following the choosing
skill's same-controller continuation branch. A new root requires an explicit
checkpoint handoff and newly verified bindings; old handles alone do not restore
continuity. If the profile or driver is unavailable, do not fabricate missing
metadata or reinterpret strict records. Use another contract-preserving route
or continue useful authorized work that needs no child operation.

## Identify the Desktop target

Use `codex-desktop` for a local Codex-backed Desktop task whose current harness
exposes leader-owned native subagent controls. A ChatGPT-backed cloud task
displayed in Desktop is a separate target. The app's user-owned task controls
do not supply this native child transport.

Before freezing a Desktop dispatch:

1. Establish the current task's product surface, target host, and available
   native controller from harness-owned context or controls. Verify that the
   controller can supply the launch, identity, context, status, and result
   observations required below. Missing or contradictory target facts block
   this route before invocation.
2. Obtain the actual application version from a product-owned observation for
   that app and host. The Codex app's `check_app_update` response exposes
   `installedVersion` from Electron's `app.getVersion()`. Its update-check
   status is separate: an unavailable update check can still return the
   installed version. Retain the complete response and its source; a missing
   or unknown version blocks the route. A CLI version, model label, launcher
   name, or worker statement cannot establish the Desktop product version.
3. Bind that observation and its app/host context into the content-addressed
   plan. Pass the observed `installedVersion` as the helper's `version` value,
   with `surface: codex-desktop` and `executor: codex`. Build and release-channel
   metadata may accompany the observation without replacing the version.
4. Reuse the observation only while its product and host context remain
   current. An app update, target change, or lost connection to the observed
   app requires a fresh observation and plan. Respect the observation control's
   usage contract; do not poll update checks per worker.

The helper binds supplied version text and opaque plan digests. It does not
authenticate the application observation or establish its freshness. The owning
workflow performs the checks above; acceptance of an input by the helper alone
does not establish a valid Desktop target. Product-version evidence does not
identify the engine or executed model, attest effective permissions, or qualify
a native review. The Desktop profile retains the assurance limits below.

## Strict-profile freeze before launch

Before freezing, consume the choosing skill's [effort eligibility](../../choosing-agent-models/references/effort-policy.md) and [named-successor capability gates](../../choosing-agent-models/references/capability-probes-and-fallbacks.md#resolve-named-successors). The native adapter binds opaque plan and request digests; it does not validate model-policy eligibility. The owning selection workflow must prove it, including inherited or executor-default effort, before launch.

First freeze the complete content-addressed Rolecasting plan, including its
exact request, target version and executor, topology, model-selection-record
identity, bounded return and stop contracts, requested authority,
and the consumer's minimum for all five assurance dimensions. Requested
authority is intent; it is not evidence that the product enforced effective
authority.

For ordinary work, this is `adapter:rolecasting-invocation-plan` with its
separate `adapter:model-selection-record`. The live record establishes available
selection and the requested model, not the model that actually executed.
Granted authority and requested restrictions remain binding without claiming
that the product attested their enforcement.

Call `freeze_native_dispatch` before invoking the native subagent tool. The
freeze binds the plan and request digests, dispatch ID, exact Codex surface,
version, executor, context, read-only authority intent, and assurance minima.
It derives the fixed child, leader-owned, native-tool topology. It rejects the
dispatch before launch when any consumer minimum exceeds the selected native
profile.

The current native tool schemas do not return a product-owned model execution
attestation or a per-spawn authority-enforcement callback. Their truthful
profile maximum is therefore:

| Evidence dimension | Maximum |
| --- | --- |
| Target | `controller-observed` |
| Model | `self-reported` |
| Topology | `controller-observed` |
| Effective authority | `self-reported` |
| Execution result | `controller-observed` |

The complete plan may bind a selected model and reasoning effort, but an opaque
plan digest does not prove that the product executed them. Likewise, prompt
denials of subdelegation and external action do not prove that the product
enforced those denials. If a consumer requires stronger model or authority
assurance, return `BLOCKED` before spawning. Do not weaken the frozen minimum
as a fallback.

## Strict-profile invoke and observe

After a successful freeze, invoke exactly one native subagent for the frozen
dispatch. Explicitly pass the selected model and reasoning effort in every
supported native creation field, following `choosing-agent-models`' field
rules for a missing control. Preserve the actual outgoing selection with the
frozen request; a plan digest alone does not apply it. Pass the bounded worker request and least authority allowed by the
live tool schema. Preserve the frozen context; a changed worktree, scope,
request, target, ownership, or authority requires a new freeze.

Take the agent or worker ID, session or task ID, context binding, and
launch acknowledgement only from the native tool protocol. Continue with the
same native controller until it returns terminal status observations and the
result observation. Preserve failed, timed-out, and cancelled terminals rather
than turning them into clean completion.

Transport completion is not usability. After the result, apply the frozen
verification and stop contracts through the same leader, retain the exact
verification observation digest, and record usability as a strict Boolean. A
`completed` transport may still be blocked, incomplete, or unverified and must
then record `usable: false`. Every non-completed terminal must also be unusable.
Never infer usability from the terminal label or model prose.

Model-generated text is never host evidence. Do not parse worker prose for its
agent ID, session, target, model, permissions, status, or result provenance.
Worker statements may remain self-reported evidence, but they cannot populate
controller-observed fields.

Call `record_native_observation` only after the terminal native result. Supply
the exact frozen binding plus the host-protocol launch, status, result, and
verification digests and the strict usability Boolean. The recorder rejects
cross-bound plan, request, dispatch, or context values, missing or out-of-order
terminal status, malformed verification, non-Boolean usability, and any usable
non-completed result. Its output is an in-process same-leader record with
`portable_evidence: false` and `product_attested: false`.

## Assurance boundary

Same-leader live controller observation is useful for ordinary operational
delegation, but it is not portable persisted attestation. The recorder is not
registered as a Task Witness producer or issuer. It cannot satisfy explicitly
witnessed publication, cannot create product-attested facts, cannot promote
self-reported model or authority facts, and cannot authenticate a result after
the live controller boundary is lost.

Ordinary review consumers may use the frozen plan, live selection record, and
verified native result within that same leader's observations. Publication
authority stays with the consuming workflow. A stronger consumer minimum still
blocks this route before spawn.

Keep the Rolecasting provider's producer and issuer inventories empty until a
qualified product integration authenticates the exact execution and binds its
own implementation identity. A controller transcript, unit test, or model
claim is not a substitute for that integration.
