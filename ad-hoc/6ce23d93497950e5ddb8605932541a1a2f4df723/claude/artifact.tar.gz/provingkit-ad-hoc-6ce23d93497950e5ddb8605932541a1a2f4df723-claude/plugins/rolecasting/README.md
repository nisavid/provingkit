# Rolecasting plugin

Rolecasting is an Agent Plugins v1 package for choosing bounded worker
topology and selecting an executable model and reasoning effort after
delegation is settled. Claude Code uses a native manifest projected from the
same canonical package identity.

Delegation freezes independent dimensions: target family, surface, version,
and executor; child, peer, or external relationship; leader-owned or user-owned
ownership; native-tool, task-api, CLI, app-server, or remote-API transport; and
the observed and consumer-minimum product-attested, controller-observed, or
self-reported assurance for each evidence dimension. Model choice remains
separate. A transport never determines the
relationship, and a user-owned peer requires explicit user consent.

Initial operational support uses separate native-child adapter profiles for
ChatGPT Codex, Codex CLI/TUI, and local Codex Desktop. All three freeze the complete plan and assurance
minima before native spawn and bind same-leader launch, status, and result
observations afterward. A separate verification digest and strict Boolean
preserve completed-but-blocked or unverified results as unusable. Their current
maximum assurance is controller-observed for target, topology, and result, and
self-reported for model and effective authority. Claude Code and Claude Desktop
follow, then Cursor and Cursor Agent together or in close succession.
Ordinary consumers use a frozen same-leader invocation plan and a separate live
model-selection record. These bind requested execution and observed capability;
they do not authenticate actual model execution or authority enforcement.
Operational support is not evidence issuance:
witnessed-publication producer and issuer qualification remains pending for every
exact surface, version, executor, transport, and assurance source.

The separate ordinary Cloud profile `chatgpt-codex-native-tree-v1` uses the
[native-tree driver](skills/delegating-cross-agent-work/references/native-tree-driver.md)
for exact native-call planning, transactional local claims, source-tagged
observations, and owner acceptance within one current controller tree.
Canonical native targets may lack separate session IDs or exposed product
builds; profile maxima remain ceilings, not achieved evidence. The agent makes
the native calls. This source support does not establish an installed release
or qualified deployment, and leaves the strict native helper, Desktop/CLI
requirements, and witnessed contracts intact.

Peer communication belongs to
[Surreal Intercom](https://github.com/nisavid/provingkit/tree/main/plugins/surreal-intercom),
through `surreal-intercom:communicating-with-agents`. Rolecasting supplies the
selected worker, task contract, authority interpretation, and supervision;
Intercom carries the addressed operation and retained message/attempt records.
Communication startup and effects use their applicable existing permission.
Installing a source candidate establishes neither live receiver reliability nor
operating adoption. Existing stores and uncertain attempts retain their original
identities and pinned source through coordinated caller cutover.

It does not decide repository ownership, review disposition, publication, or
pull-request work.

## Skills

| Public name                                | Responsibility                                                                                                                             |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------ |
| `$rolecasting:delegating-cross-agent-work` | Freeze target, relationship, ownership, transport, assurance, and authority; batch same-shape work, use bounded waits, and retain leader integration. |
| `$rolecasting:choosing-agent-models`       | Select a model-effort pair proven by the live-catalog and target-executor-schema intersection after delegation is settled, including effect-separated Daybreak account-home routing. |

## Layout

```text
plugins/rolecasting/
├── plugin.json                     # Canonical Agent Plugins v1 manifest
├── .claude-plugin/plugin.json      # Validated Claude identity projection
├── task-witness-provider.json      # Dispatch-evidence owner registration
├── content-lock.json               # Generated semantic and rubric snapshot
├── evals/delivery.json             # Isolated executor/grader delivery contract
├── skills/                         # Skills, owner validator, references, and evals
└── topology.json                    # Authoritative ownership and call graph
```

The root manifest is the sole package identity and carries Codex presentation
metadata under `extensions.com.openai.interface`. The Claude manifest is an
exact projection of the common identity fields with only Claude's
`displayName` added. The single `skills/` tree is portable; Codex selectively
reads each preserved `skills/*/agents/openai.yaml` interface. Skill discovery
supplies the `rolecasting:` namespace, and every relative runtime resource
stays inside the package. The `schema_version` in `topology.json` versions
Rolecasting's local topology shape, not a repository-wide interchange schema.

Rolecasting's registered owner validator accepts a strict, generic dispatch
bundle and returns `rolecasting-dispatch-projection-v2`. Its pure renderer
cannot authenticate a selected executor, and no authenticated owning harness
integration is currently bound into the issuer identity. The registered
provider therefore declares empty producer and issuer inventories and retains
only the active validator plus its exact renderer module. Task Witness is optional future equipment for callers that require a stronger
cross-harness evidence contract. Without it, the pure validator can check
structure and identity, while issuer or producer authority remains unavailable.

The owner interface is documented in the delegating skill's
`dispatch-evidence.md` reference. Rolecasting's dispatch evidence exposes no
trust-path or worker-launch CLI and does not interpret review or publication
semantics. Its separate
native adapter deterministically freezes supplied, already-observed execution
facts; it does not launch workers or claim to authenticate observations the
harness has not supplied. Its `rolecasting-bootstrap-adapter-v2` issuer contract
is independent of the dispatch-evidence bundle contract. Private tests may
construct test-owned bootstrap trust to exercise historical validation, but no
Rolecasting historical trust has been installed and those results cannot
become authenticated evidence for witnessed publication. The skill-mediated
native Codex module supports separate ChatGPT Codex, CLI/TUI, and local Desktop
profiles. Follow its [native binding procedure](skills/delegating-cross-agent-work/references/native-codex-subagents.md)
to identify the product and observe the Desktop application version. The module
sequences pre-spawn freeze and post-result same-leader recording, but it is not
a harness actuator and emits neither portable evidence
nor product attestation. Explicitly witnessed publication stays blocked until a
real native harness integration authenticates execution and its exact owning
bytes are bound into a newly registered producer/issuer identity.
That witnessed route requires a product-attested ChatGPT Codex
child. Ordinary consumers require controller-observed assurance for every fact
they rely on. Self-reported dimensions are diagnostic and non-gating; the
native route is usable only when actual model execution and effective authority
are not gate inputs. Live selection capability and granted or requested
authority remain ordinary plan inputs. The publication owner separately decides
whether ordinary publication is authorized; these records do not grant it.
The validator preserves both clean and nonclean execution evidence: `usable` is
a strict Boolean carried into every execution projection, and `false` remains a
valid result rather than being discarded.

### Daybreak account-home routing

`choosing-agent-models` carries separate catalog and selected-account programs.
The catalog program validates one explicitly supplied maintained-format Markdown
catalog and can emit redacted positions or one explicit private selection. The
status-only account program accepts only that strict selection on standard
input. Its status operation uses the provider's identity-bearing rate-limit
bootstrap reply to bind the selected account before model discovery, then
queries the exact model without creating a task thread. Its bounded transport
discards unused notifications and exposes only fixed diagnostics. Its
harmless-probe operation is explicitly unavailable
and fails before authentication access or launch because the public Codex
controls do not provide a closed-world task-tool deny. The skill's
`references/daybreak-routing.md` owns the full invocation and effect contract.

## Validation

From the repository root, run:

```sh
uv run --with PyYAML python scripts/validate_rolecasting.py
uv run --with PyYAML python -m unittest tests/test_agent_plugins_standard.py
uv run --with PyYAML python -m unittest tests/test_validate_rolecasting.py
python3 -m unittest tests/test_rolecasting_eval_corpus.py
python3 -m unittest tests/plugins/test_rolecasting_dispatch_evidence.py
python3 -m unittest tests/plugins/test_rolecasting_native_codex.py
python3 -m unittest tests/plugins/test_rolecasting_native_tree.py
python3 -m unittest tests/plugins/test_rolecasting_daybreak_routing.py
```

The validator rejects Agent Plugins schema drift, duplicate keys and non-finite
JSON, malformed discovery YAML, invalid CLI arity, non-direct skill discovery,
resource escapes, component drift, non-portable content, projection or adapter
namespace drift, graph invariant violations, semantic-lock drift, grader-answer
leakage, and lexical ancestor symlinks.
