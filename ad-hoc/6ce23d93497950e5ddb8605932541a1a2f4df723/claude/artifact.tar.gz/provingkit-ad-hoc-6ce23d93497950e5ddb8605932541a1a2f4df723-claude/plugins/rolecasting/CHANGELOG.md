# Changelog

## Unreleased

- Use Claude Fable 5.2 as the exceptional-tier baseline, the Claude Sage
  Ultracode target, and the authorized deep-cognition fallback for actual
  cybersecurity work. Require current proof for the selected pair on its
  exact target.

- Select Terra Low/Medium/High on the useful economical frontier, preserving
  narrow committed-code suitability, browser competence, and validated low-poly
  prototype handoffs. Exclude Sol Light and Luna XHigh/Max; prefer Sol Medium
  over Terra XHigh without declaring that supported pair unavailable.
- Define Sage-supported orchestrator and Dispatch defaults and standing defaults
  for Concierge and scoped Reception. Preserve decision-facing Foreman bindings,
  accepted interim, and cutover authority. Verify native controls, effective
  selection, and persistence separately from selected policy. Use Haiku 5.5 for
  bounded work, Claude Dispatch at High, and Claude Concierge at XHigh.

- Test insufficient low effort and sufficient high effort within Grok's
  maintained task role.

- Establish Grok role suitability and high-effort judgment margin in the
  positive current-version selection fixture.

- Grade unavailable routes on refusal and owner control; explicitly elicit
  fallback consent actions, user-owned task prerequisites, and leader
  responsibility assignments.

- Require independent catalog and executor proof for every fallback pair, and
  exercise unsuitable and suitable Cursor reviews, useful Ultra without
  panels, witnessed-route prerequisites, and concrete specialist input selection.

- Clarify the discovery boundary between delegation and model selection in the
  delegation skill's description.

- Route ordinary demanding work to GPT-6.1 Sol or Opus, prefer proven newer
  same-name GPT/Claude versions, restore Sonnet 5.5 for its shallow-cognition
  middle tier, and require medium-or-higher effort for Astra/Fable and Sol/Opus.
  Bind OpenAI/Anthropic max to all model, frontier-problem, panel-loop, and
  capability gates; encourage useful Ultra/Ultracode panels with independently
  selected participant efforts.

- Separate ordinary same-leader invocation plans and live selection records
  from explicitly witnessed receipts, preserving native assurance limits and
  each consumer's existing authority and verification gates.
- Re-prove the original account binding before every task continuation, bind
  alternate-account Codex CLI resumes with explicit `CODEX_HOME`, and reject
  ambient resumes before sending task data when account affinity is unproven.
- Define target, relationship, ownership, transport, and assurance as
  independent delegation dimensions, with model choice kept separate.
- Require controller-observed evidence for every fact an ordinary consumer
  relies on and product-attested ChatGPT Codex child evidence for canonical
  publication; self-reported dimensions remain diagnostic and non-gating.
- Bind the consumer's per-dimension assurance minimum before dispatch and
  reject any observed target, model, topology, authority, or result evidence
  below it.
- Publish the qualification order for separate ChatGPT Codex and Codex CLI/TUI
  surfaces, followed by Claude Code and Claude Desktop, then Cursor and Cursor
  Agent, without claiming that validator-only support can issue evidence.
- Register the strict generic dispatch-evidence owner with Task Witness and
  emit a canonical projection without taking review or publication authority.
- Bind producer and issuer identities to a separate native adapter that
  deterministically freezes already-observed execution facts without claiming
  to launch or authenticate the worker itself.
- Keep the native adapter issuer contract independent from the dispatch-
  evidence bundle contract.
- Fail closed by omitting the unauthenticated producer and issuer from the
  current provider; retain only the validator and its bootstrap-renderer module
  until an authenticated native harness integration exists.
- Preserve failed, timed-out, incomplete, and other nonclean execution evidence
  by accepting strict Boolean `usable: false` and projecting the exact status.
- Add separate ChatGPT Codex and Codex CLI/TUI native-child profiles with an
  executable pre-spawn freeze and post-result recording seam. Bind exact
  plan/request identity and native launch, status, result, agent, session, and
  context observations without parsing worker text as host evidence.
- Keep native model and effective-authority assurance self-reported until the
  product exposes an exact model and per-spawn enforcement observation. Reject
  stronger consumer minima before spawn and keep the binding outside provider
  producer and issuer registration.
- Separate native transport completion from verified usability. Bind the
  same-leader verification observation and strict usability Boolean, preserve
  completed-but-blocked or unverified results as unusable, and reject a usable
  non-completed terminal.

## 1.0.0

Initial Agent Plugins v1 package for delegation topology, bounded authority,
live-capability model selection, and leader integration. The root manifest owns
the `1.0.0` identity, Codex metadata uses `extensions.com.openai.interface`, and
Claude Code uses a validated native projection.
