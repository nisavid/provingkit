# Proseweaving plugin

Proseweaving is an Agent Plugins v1 plugin for prose that agents write to
people: the register a reader should meet, the evidence discipline behind
every claim in that prose, the post-draft edit passes that enforce style as
actions rather than preferences, and the adversarial pass that reads a finished
draft as its recipient before it ships. Claude Code uses a native manifest
projected from the same canonical plugin identity.

Writing standards are portable equipment here, not personal taste: a consumer
without the author's own global instructions still receives the mechanics.
Personal voice composes on top through consumer-global instructions and never
lives in this plugin.

Proseweaving owns generic human-facing prose mechanics, including selection of
register for a publication, document, or conversation. Its general writing
skill applies to authored PR and Issue prose as well as other human-facing
text; conversational openings and reply etiquette live in a conditional
reference. Surface owners keep their content and format contracts: Mergecraft
owns reviewer-facing pull-request text and review-specific framing, and
Tricritical owns review findings and their structural output contract. Compose
those contracts with Proseweaving while preserving their retained-text and
publication boundaries; projections do not cross plugin boundaries.

Claude Code also discovers the native `proseweaver` agent alias. It is a thin
forwarder to the public skill, so the skill remains the portable policy owner.
Codex and other Agent Plugins clients consume the standard skill surface and do
not load this Claude-native agent definition.

## Public skills

<!-- BEGIN GENERATED SKILL ROSTER -->
| Skill | Owns | Calls |
| --- | --- | --- |
| `writing-for-people` | human-facing-register, evidence-in-prose, post-draft-edit-pass | - |
<!-- END GENERATED SKILL ROSTER -->

## Adapter boundary

Root `plugin.json` and `skills/` are the canonical Agent Plugins plugin root;
`.claude-plugin/plugin.json` is a projection of the same identity. Skill-to-skill
edges use literal public identities linked to sibling `SKILL.md` files. Codex
adapters and each skill's `agents/openai.yaml` use `$proseweaving:<skill>` targets.
The root `agents/proseweaver.md` file is a Claude-native adapter and is not a
portable Agent Plugins component. The roster projection above is generated from
`topology.json` by the content-lock writer.

## Validation

`python -m unittest tests.test_validate_proseweaving` exercises the focused
contract suite. `python3 scripts/validate_proseweaving.py .` validates the plugin from the
repository root: manifest identity and projection, topology, skill contracts,
the generated roster projection, inventory, portability, and the semantic content lock.
`--write-content-lock` regenerates the roster projection and the lock after an
authored change. `evals/delivery.json` governs plugin delivery, while
`skills/writing-for-people/evals/evals.json` carries the skill behavior corpus.
The plugin declares no Task Witness provider yet; publication eligibility and
inclusion in a release slate is decided outside this plugin.
