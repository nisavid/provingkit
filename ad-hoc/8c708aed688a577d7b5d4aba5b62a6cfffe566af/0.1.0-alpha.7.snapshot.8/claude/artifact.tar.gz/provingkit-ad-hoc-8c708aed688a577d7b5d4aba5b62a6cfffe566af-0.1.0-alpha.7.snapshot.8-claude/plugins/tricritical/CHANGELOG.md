# Changelog

## 0.1.0-trunk

- Align the source and Claude adapter versions with the Kit's synchronized
  `0.1.0-trunk` development identity.

## Historical source changes (mistakenly labeled 1.0.0)

Uses Agent Plugins v1 as the canonical skills package, with native Claude agent
aliases and skill-local Codex metadata retained for unsupported client surfaces.

Initial portable Tricritical review core: three independent critics, evidence-based adjudication, one authority-gated reviser, and one fixed-point loop.

Adds the v2 terminal-review evidence validator and Task Witness projection. The
projection preserves Rolecasting v2 target, topology, authority, result, and
assurance evidence without promotion. The provider remains validator-only while
authenticated Rolecasting execution is unavailable.
